
export class LuaRunner {
  private static instance: LuaRunner;
  
  private constructor() {}

  static getInstance() {
    if (!this.instance) {
      this.instance = new LuaRunner();
    }
    return this.instance;
  }

  validate(code: string): { line: number; message: string } | null {
    if (!window.fengari) return null;
    const { lua, lauxlib, to_luastring, to_jsstring } = window.fengari;
    const L = lauxlib.luaL_newstate();
    
    const status = lauxlib.luaL_loadstring(L, to_luastring(code));
    if (status !== 0) {
      const errorMsg = to_jsstring(lua.lua_tostring(L, -1));
      // Format: [string "code"]:line: message
      const match = errorMsg.match(/:(\d+): (.*)/);
      if (match) {
        return {
          line: parseInt(match[1], 10),
          message: match[2]
        };
      }
      return { line: 1, message: errorMsg };
    }
    return null;
  }

  run(code: string, onPrint: (text: string) => void, onError: (text: string) => void) {
    if (!window.fengari) {
      onError("Fengari Lua VM not loaded.");
      return;
    }

    const { lua, lauxlib, lualib, to_luastring, to_jsstring } = window.fengari;
    const L = lauxlib.luaL_newstate();
    lualib.luaL_openlibs(L);

    const printFunc = (L: any) => {
      const n = lua.lua_gettop(L);
      let s = "";
      for (let i = 1; i <= n; i++) {
        const type = lua.lua_type(L, i);
        let val;
        if (type === lua.LUA_TNUMBER) val = lua.lua_tonumber(L, i);
        else if (type === lua.LUA_TSTRING) val = to_jsstring(lua.lua_tostring(L, i));
        else if (type === lua.LUA_TBOOLEAN) val = lua.lua_toboolean(L, i) ? "true" : "false";
        else val = `[${lua.lua_typename(L, type)}]`;
        s += val + (i < n ? "\t" : "");
      }
      onPrint(s);
      return 0;
    };

    lua.lua_pushjsfunction(L, printFunc);
    lua.lua_setglobal(L, "print");

    const status = lauxlib.luaL_dostring(L, to_luastring(code));
    if (status !== 0) {
      const errorMsg = to_jsstring(lua.lua_tostring(L, -1));
      onError(errorMsg);
    }
  }
}
