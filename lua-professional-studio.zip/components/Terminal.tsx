
import React, { useEffect, useRef } from 'react';
import { TerminalMessage } from '../types';

interface TerminalProps {
  messages: TerminalMessage[];
  onClear: () => void;
}

const Terminal: React.FC<TerminalProps> = ({ messages, onClear }) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="h-1/3 flex flex-col border-t border-border-dark bg-background-dark">
      <div className="flex border-b border-border-dark px-4 bg-background-dark">
        <button className="px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-white border-b border-primary">Terminal</button>
        <button className="px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-gray-500 hover:text-gray-300">Output</button>
        <button className="px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-gray-500 hover:text-gray-300">Debug Console</button>
        <div className="ml-auto flex items-center gap-4">
          <span className="text-[10px] text-gray-500 font-mono">lua-5.4</span>
          <span className="material-symbols-outlined !text-[16px] text-gray-500 cursor-pointer hover:text-white" onClick={onClear}>delete</span>
        </div>
      </div>
      <div className="flex-1 overflow-auto p-4 font-mono text-sm">
        <div className="flex flex-col gap-1">
          {messages.length === 0 && (
            <div className="text-gray-600 italic">No output yet. Press 'Run' to execute your script.</div>
          )}
          {messages.map((msg, idx) => (
            <div key={idx} className="flex gap-2">
              {msg.type === 'input' && <span className="text-primary font-bold">user@lua-ide:~$</span>}
              <span className={`
                ${msg.type === 'error' ? 'text-red-400' : ''}
                ${msg.type === 'info' ? 'text-gray-400 italic' : ''}
                ${msg.type === 'success' ? 'text-primary' : ''}
                ${msg.type === 'input' ? 'text-white' : ''}
              `}>
                {msg.text}
              </span>
            </div>
          ))}
          <div ref={endRef} />
        </div>
      </div>
    </div>
  );
};

export default Terminal;
