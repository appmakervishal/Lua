
import React from 'react';
import { FileNode } from '../types';

interface ExplorerProps {
  files: FileNode[];
  activeFileId: string;
  onSelectFile: (id: string) => void;
  onToggleFolder: (id: string) => void;
  onCreateFile: (parentId: string) => void;
}

const Explorer: React.FC<ExplorerProps> = ({ files, activeFileId, onSelectFile, onToggleFolder, onCreateFile }) => {
  const renderNode = (node: FileNode, depth = 0) => {
    const isFile = node.type === 'file';
    const isActive = activeFileId === node.id;
    
    return (
      <div key={node.id}>
        <div 
          className={`group px-4 py-1 flex items-center gap-2 text-xs cursor-pointer transition-colors ${
            isActive ? 'text-white bg-accent-dark border-l border-primary/50' : 'text-gray-400 hover:bg-accent-dark'
          }`}
          style={{ paddingLeft: `${(depth + 1) * 12}px` }}
          onClick={() => isFile ? onSelectFile(node.id) : onToggleFolder(node.id)}
        >
          <span className={`material-symbols-outlined !text-[16px] ${
            isFile ? (node.name.endsWith('.json') ? 'text-gray-500' : 'text-primary') : 'text-blue-400'
          }`}>
            {isFile ? (node.name.endsWith('.json') ? 'settings' : 'description') : (node.isOpen ? 'keyboard_arrow_down' : 'chevron_right')}
          </span>
          <span className={`flex-1 truncate ${isFile ? '' : 'font-bold'}`}>{node.name}</span>
          {!isFile && (
            <button 
              className="opacity-0 group-hover:opacity-100 hover:text-white transition-opacity p-0.5"
              onClick={(e) => { e.stopPropagation(); onCreateFile(node.id); }}
              title="New File"
            >
              <span className="material-symbols-outlined !text-[14px]">note_add</span>
            </button>
          )}
        </div>
        {!isFile && node.isOpen && node.children?.map(child => renderNode(child, depth + 1))}
      </div>
    );
  };

  return (
    <aside className="w-60 bg-panel-dark border-r border-border-dark flex flex-col shrink-0">
      <div className="px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-gray-500 flex justify-between items-center">
        Explorer
        <div className="flex gap-1">
          <button className="material-symbols-outlined !text-[16px] cursor-pointer hover:text-white transition-colors" title="Refresh">refresh</button>
          <button className="material-symbols-outlined !text-[16px] cursor-pointer hover:text-white transition-colors">more_horiz</button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto pt-2">
        {files.map(node => renderNode(node))}
      </div>
    </aside>
  );
};

export default Explorer;
