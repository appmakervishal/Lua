
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { LuaRunner } from '../services/luaRunner';

interface EditorProps {
  content: string;
  onChange: (value: string) => void;
}

const LUA_KEYWORDS = [
  'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function',
  'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then',
  'true', 'until', 'while'
];

const LUA_BUILTINS = [
  'print', 'require', 'math', 'table', 'string', 'io', 'os', 'debug',
  'type', 'pairs', 'ipairs', 'assert', 'error', 'pcall', 'xpcall',
  'collectgarbage', 'getmetatable', 'setmetatable', 'next', 'rawequal',
  'rawget', 'rawlen', 'rawset', 'select', 'tonumber', 'tostring'
];

const LUA_LIBS: Record<string, string[]> = {
  math: ['abs', 'acos', 'asin', 'atan', 'ceil', 'cos', 'deg', 'exp', 'floor', 'fmod', 'huge', 'log', 'max', 'maxinteger', 'min', 'mininteger', 'modf', 'pi', 'rad', 'random', 'randomseed', 'sin', 'sqrt', 'tan', 'tointeger', 'type', 'ult'],
  string: ['byte', 'char', 'dump', 'find', 'format', 'gmatch', 'gsub', 'len', 'lower', 'match', 'pack', 'packsize', 'rep', 'reverse', 'sub', 'unpack', 'upper'],
  table: ['concat', 'insert', 'move', 'pack', 'remove', 'sort', 'unpack'],
  os: ['clock', 'date', 'difftime', 'execute', 'exit', 'getenv', 'remove', 'rename', 'setlocale', 'time', 'tmpname'],
  io: ['close', 'flush', 'input', 'lines', 'open', 'output', 'popen', 'read', 'tmpfile', 'type', 'write'],
  debug: ['debug', 'getuservalue', 'gethook', 'getinfo', 'getlocal', 'getmetatable', 'getregistry', 'getupvalue', 'sethook', 'setlocal', 'setmetatable', 'setupvalue', 'setuservalue', 'traceback', 'upvalueid', 'upvaluejoin'],
  package: ['config', 'cpath', 'loaded', 'loadlib', 'path', 'preload', 'searchers', 'searchpath']
};

const ALL_GLOBAL_SUGGESTIONS = [...LUA_KEYWORDS, ...LUA_BUILTINS];

const Editor: React.FC<EditorProps> = ({ content, onChange }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLDivElement>(null);
  const [lineNumbers, setLineNumbers] = useState<number[]>([]);
  const [syntaxError, setSyntaxError] = useState<{ line: number; message: string } | null>(null);
  
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [suggestionPos, setSuggestionPos] = useState({ top: 0, left: 0 });
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      const error = LuaRunner.getInstance().validate(content);
      setSyntaxError(error);
    }, 200);
    return () => clearTimeout(timer);
  }, [content]);

  useEffect(() => {
    const lines = content.split('\n').length;
    setLineNumbers(Array.from({ length: Math.max(lines, 1) }, (_, i) => i + 1));
  }, [content]);

  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (highlightRef.current) {
      highlightRef.current.scrollTop = e.currentTarget.scrollTop;
      highlightRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
  };

  const getCursorXY = (element: HTMLTextAreaElement, startIndex: number) => {
    const { offsetLeft: elLeft, offsetTop: elTop } = element;
    const textBeforeCursor = element.value.substring(0, startIndex);
    const lines = textBeforeCursor.split('\n');
    const currentLine = lines.length;
    const currentColumn = lines[lines.length - 1].length;
    
    const lineHeight = 24; 
    const charWidth = 8.4; 
    
    return {
      top: elTop + (currentLine * lineHeight) + 20 - element.scrollTop,
      left: elLeft + (currentColumn * charWidth) + 16 - element.scrollLeft
    };
  };

  const applySuggestion = (word: string) => {
    if (!textareaRef.current) return;
    const start = textareaRef.current.selectionStart;
    const value = textareaRef.current.value;
    const before = value.substring(0, start);
    const after = value.substring(start);
    
    const memberMatch = before.match(/([a-zA-Z_]\w*)\.([a-zA-Z_]\w*)?$/);
    const wordMatch = before.match(/[a-zA-Z_]\w*$/);

    let newValue = "";
    let newCursorPos = 0;

    if (memberMatch) {
      const prefix = before.substring(0, before.length - (memberMatch[2]?.length || 0));
      newValue = prefix + word + after;
      newCursorPos = prefix.length + word.length;
    } else if (wordMatch) {
      const prefix = before.substring(0, wordMatch.index);
      newValue = prefix + word + after;
      newCursorPos = prefix.length + word.length;
    }

    if (newValue) {
      onChange(newValue);
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus();
          textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
        }
      }, 0);
    }
    setShowSuggestions(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (showSuggestions) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % suggestions.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + suggestions.length) % suggestions.length);
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        applySuggestion(suggestions[selectedIndex]);
        return;
      }
      if (e.key === 'Escape') {
        setShowSuggestions(false);
        return;
      }
    }

    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.currentTarget.selectionStart;
      const end = e.currentTarget.selectionEnd;
      const value = e.currentTarget.value;
      const newValue = value.substring(0, start) + '    ' + value.substring(end);
      onChange(newValue);
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 4;
        }
      }, 0);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    onChange(val);
    const cursorPos = e.target.selectionStart;
    const textBefore = val.substring(0, cursorPos);

    // Check for library member access (e.g., "math.")
    const memberMatch = textBefore.match(/([a-zA-Z_]\w*)\.([a-zA-Z_]\w*)?$/);
    if (memberMatch) {
      const libName = memberMatch[1];
      const memberPrefix = memberMatch[2] || "";
      if (LUA_LIBS[libName]) {
        const filtered = LUA_LIBS[libName].filter(m => m.startsWith(memberPrefix));
        if (filtered.length > 0) {
          setSuggestions(filtered);
          setSelectedIndex(0);
          setSuggestionPos(getCursorXY(e.target, cursorPos));
          setShowSuggestions(true);
          return;
        }
      }
    }

    // Fallback to global suggestions
    const lastWordMatch = textBefore.match(/[a-zA-Z_]\w*$/);
    if (lastWordMatch) {
      const lastWord = lastWordMatch[0];
      const filtered = ALL_GLOBAL_SUGGESTIONS.filter(s => s.startsWith(lastWord) && s !== lastWord);
      if (filtered.length > 0) {
        setSuggestions(filtered);
        setSelectedIndex(0);
        setSuggestionPos(getCursorXY(e.target, cursorPos));
        setShowSuggestions(true);
      } else {
        setShowSuggestions(false);
      }
    } else {
      setShowSuggestions(false);
    }
  };

  const highlightLua = useCallback((code: string) => {
    const lines = code.split('\n');
    return lines.map((line, lineIdx) => {
      let escaped = line
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

      const tokens: { placeholder: string; html: string }[] = [];
      let tokenCounter = 0;

      const addToken = (html: string) => {
        const placeholder = `\x01${tokenCounter++}\x01`;
        tokens.push({ placeholder, html });
        return placeholder;
      };

      // 1. Strings
      escaped = escaped.replace(/(["'])(?:(?=(\\?))\2.)*?\1|\[\[[\s\S]*?\]\]/g, (match) => 
        addToken(`<span class="text-yellow-200">${match}</span>`)
      );

      // 2. Comments
      escaped = escaped.replace(/--.*/g, (match) => 
        addToken(`<span class="text-[#4b6b58] italic">${match}</span>`)
      );

      // 3. Keywords
      const keywordRegex = new RegExp(`\\b(${LUA_KEYWORDS.join('|')})\\b`, 'g');
      escaped = escaped.replace(keywordRegex, (match) => 
        addToken(`<span class="text-primary font-bold">${match}</span>`)
      );

      // 4. Builtins
      const builtinRegex = new RegExp(`\\b(${LUA_BUILTINS.join('|')})\\b`, 'g');
      escaped = escaped.replace(builtinRegex, (match) => 
        addToken(`<span class="text-blue-400 font-medium">${match}</span>`)
      );

      // 5. Constants & Numbers
      escaped = escaped.replace(/\b(nil|true|false)\b/g, (match) => 
        addToken(`<span class="text-orange-400 italic">${match}</span>`)
      );
      escaped = escaped.replace(/\b\d+(\.\d+)?\b/g, (match) => 
        addToken(`<span class="text-orange-400">${match}</span>`)
      );

      let finalHtml = escaped;
      for (let i = tokens.length - 1; i >= 0; i--) {
        finalHtml = finalHtml.replace(tokens[i].placeholder, tokens[i].html);
      }

      const currentLineNum = lineIdx + 1;
      const isErrorLine = syntaxError && syntaxError.line === currentLineNum;

      return (
        `<div class="h-6 leading-6 w-full relative group">` +
          (isErrorLine ? `<div class="absolute inset-x-0 bottom-0 h-0.5 bg-red-500/30 bg-[radial-gradient(circle,red_1px,transparent_1px)] bg-[length:4px_4px] pointer-events-none"></div>` : '') +
          `<span>${finalHtml || ' '}</span>` +
          (isErrorLine ? `<div class="absolute left-0 top-6 hidden group-hover:block z-50 bg-red-900 text-red-100 text-[10px] px-2 py-1 rounded shadow-lg border border-red-700 pointer-events-none">${syntaxError.message}</div>` : '') +
        `</div>`
      );
    }).join('');
  }, [syntaxError]);

  const getSuggestionType = (word: string) => {
    if (LUA_KEYWORDS.includes(word)) return 'keyword';
    if (LUA_BUILTINS.includes(word)) return 'builtin';
    return 'member';
  };

  return (
    <div className="flex-1 flex overflow-hidden bg-panel-dark font-mono text-sm relative border-b border-border-dark">
      <div className="line-numbers w-12 flex flex-col items-end pt-4 pr-3 text-gray-600 select-none bg-background-dark/30 border-r border-border-dark shrink-0">
        {lineNumbers.map(num => (
          <div key={num} className={`h-6 leading-6 text-right w-full ${syntaxError?.line === num ? 'text-red-500 font-bold bg-red-950/20' : ''}`}>
            {num}
          </div>
        ))}
      </div>
      <div className="relative flex-1 overflow-hidden">
        <textarea
          ref={textareaRef}
          className="code-input w-full h-full p-4 pt-4 leading-6 font-mono whitespace-pre border-none focus:ring-0 overflow-auto scroll-smooth"
          value={content}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onScroll={handleScroll}
          spellCheck={false}
          autoCapitalize="none"
          autoComplete="off"
        />
        <div
          ref={highlightRef}
          className="code-highlight w-full h-full p-4 pt-4 leading-6 font-mono whitespace-pre overflow-hidden"
          dangerouslySetInnerHTML={{ __html: highlightLua(content) }}
        />

        {showSuggestions && (
          <div 
            className="fixed z-[100] bg-background-dark border border-border-dark rounded shadow-2xl py-1 min-w-[160px] max-h-48 overflow-y-auto"
            style={{ 
              top: Math.min(suggestionPos.top, window.innerHeight - 200), 
              left: Math.min(suggestionPos.left, window.innerWidth - 180) 
            }}
          >
            {suggestions.map((s, i) => (
              <div
                key={s}
                className={`px-3 py-1.5 text-xs cursor-pointer flex items-center justify-between gap-4 ${i === selectedIndex ? 'bg-primary text-background-dark font-bold' : 'text-gray-300 hover:bg-accent-dark'}`}
                onClick={() => applySuggestion(s)}
              >
                <span className="truncate">{s}</span>
                <span className={`text-[9px] uppercase tracking-tighter opacity-60 ${i === selectedIndex ? 'text-background-dark/70' : 'text-primary'}`}>
                  {getSuggestionType(s)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Editor;
